
public class Main {
    public static void main(String[] args) {
        Model model = new Model();
        MainView mainView = new MainView(model);
    }
}
